require 'rubygems'
require 'spec'
require 'spec/autorun'
require 'spec/interop/test'
require 'webmock/rspec'

include WebMock

